#include <raylib.h>
#include <memory>

// Core
#include "core/constants.hpp"
#include "core/theme.hpp"
#include "core/resource_manager.hpp"
#include "core/coordinate_system.hpp"

// Systems
#include "systems/state_machine.hpp"
#include "systems/render_system.hpp"
#include "systems/input_system.hpp"
#include "systems/movement_system.hpp"
#include "systems/camera_system.hpp"
#include "systems/collision_system.hpp"

// Entities
#include "entities/player.hpp"
#include "entities/map.hpp"

// Rendering
#include "rendering/camera.hpp"
#include "rendering/debug_overlay.hpp"

using namespace std;

// Game State Enum
enum class GameState {
    MAIN_MENU,
    PLAYING,
    PAUSED,
    INVENTORY,
    GAME_OVER
};

int main() {
    // Initialize window
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Diablo Clone");
    SetTargetFPS(60);
    
    // Initialize systems
    auto resourceManager = make_shared<ResourceManager>();
    auto coordSystem = make_shared<CoordinateSystem>();
    auto camera = make_shared<Camera>();
    auto stateMachine = make_shared<StateMachine>();
    
    // Create game objects
    auto player = make_shared<Player>();
    auto map = make_shared<Map>();
    
    // Initialize systems
    auto renderSystem = make_shared<RenderSystem>(camera, resourceManager);
    auto inputSystem = make_shared<InputSystem>();
    auto movementSystem = make_shared<MovementSystem>();
    auto cameraSystem = make_shared<CameraSystem>(camera, player);
    auto collisionSystem = make_shared<CollisionSystem>();
    
    // Setup debug overlay
    DebugOverlay debugOverlay;
    
    // Load resources
    resourceManager->LoadTexture("player", "assets/textures/player.png");
    resourceManager->LoadTexture("tiles", "assets/textures/tileset.png");
    
    // Setup player
    player->Initialize({SCREEN_WIDTH / 2, SCREEN_HEIGHT / 2});
    player->SetTexture(resourceManager->GetTexture("player"));
    
    // Setup map
    map->Load("assets/maps/dungeon1.tmx");
    
    // Set initial game state
    GameState currentState = GameState::PLAYING;
    
    // Main game loop
    while (!WindowShouldClose()) {
        float deltaTime = GetFrameTime();
        
        // Update input system
        inputSystem->Update();
        
        // Handle game states
        switch (currentState) {
            case GameState::PLAYING: {
                // Update player input
                Vector2 input = inputSystem->GetMovementInput();
                player->SetVelocity(input);
                
                // Update movement
                movementSystem->Update(player, deltaTime);
                
                // Check collisions
                collisionSystem->CheckCollisions(player, map);
                
                // Update camera
                cameraSystem->Update(deltaTime);
                
                // Debug controls
                if (IsKeyPressed(KEY_F1)) {
                    debugOverlay.Toggle();
                }
                
                // Pause game
                if (IsKeyPressed(KEY_ESCAPE)) {
                    currentState = GameState::PAUSED;
                }
                break;
            }
            
            case GameState::PAUSED: {
                if (IsKeyPressed(KEY_ESCAPE)) {
                    currentState = GameState::PLAYING;
                }
                if (IsKeyPressed(KEY_ENTER)) {
                    currentState = GameState::MAIN_MENU;
                }
                break;
            }
            
            case GameState::MAIN_MENU: {
                // Menu logic here
                if (IsKeyPressed(KEY_ENTER)) {
                    currentState = GameState::PLAYING;
                }
                break;
            }
        }
        
        // Begin drawing
        BeginDrawing();
        ClearBackground(GetColor(Theme::backgroundColor));
        
        // Begin mode2D for game rendering
        cameraSystem->BeginMode2D();
        
        // Render game world
        renderSystem->RenderMap(map);
        renderSystem->RenderEntity(player);
        
        // End mode2D
        cameraSystem->EndMode2D();
        
        // Render UI
        switch (currentState) {
            case GameState::PAUSED:
                DrawRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, {0, 0, 0, 180});
                DrawText("PAUSED", SCREEN_WIDTH/2 - 60, SCREEN_HEIGHT/2 - 20, 40, WHITE);
                DrawText("Press ESC to resume", SCREEN_WIDTH/2 - 100, SCREEN_HEIGHT/2 + 30, 20, LIGHTGRAY);
                break;
                
            case GameState::MAIN_MENU:
                DrawRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, {0, 0, 0, 220});
                DrawText("DIABLO CLONE", SCREEN_WIDTH/2 - 150, SCREEN_HEIGHT/2 - 100, 50, RED);
                DrawText("Press ENTER to start", SCREEN_WIDTH/2 - 120, SCREEN_HEIGHT/2, 30, WHITE);
                break;
        }
        
        // Render debug overlay
        if (debugOverlay.IsVisible()) {
            debugOverlay.Update(deltaTime);
            debugOverlay.Render();
        }
        
        // Draw FPS
        DrawFPS(10, 10);
        
        EndDrawing();
    }
    
    // Cleanup
    resourceManager->UnloadAll();
    
    CloseWindow();
    return 0;
}