// render_system.hpp - Z-sıralamalı render sistemi
#ifndef RENDER_SYSTEM_HPP
#define RENDER_SYSTEM_HPP

#include "types.hpp"
#include <vector>
#include <algorithm>

class RenderSystem {
public:
    static RenderSystem& GetInstance() {
        static RenderSystem instance;
        return instance;
    }
    
    // Draw queue'ya komut ekle
    void SubmitDrawCommand(int sortKey, void (*drawFunc)(void*), void* context) {
        m_drawQueue.push_back({sortKey, drawFunc, context});
    }
    
    // Z-order'a göre sırala ve çiz
    void FlushDrawQueue() {
        // Sort by Y-position (isometric depth)
        std::sort(m_drawQueue.begin(), m_drawQueue.end());
        
        // Execute draw commands
        for (auto& cmd : m_drawQueue) {
            if (cmd.drawFunction) {
                cmd.drawFunction(cmd.context);
            }
        }
        
        // Clear queue for next frame
        m_drawQueue.clear();
    }
    
    // Calculate sort key for isometric depth
    static int CalculateSortKey(Vector2 worldPos, int entityType = 0) {
        // Primary sort by Y position (isometric depth)
        // Add entity type as secondary sort (player, enemy, item, etc.)
        int yKey = static_cast<int>(worldPos.y * 100.0f);
        
        // Entity type in higher bits
        int typeKey = entityType << 24;
        
        return yKey + typeKey;
    }
    
    // Batch rendering için yardımcılar
    void BeginFrame() {
        m_drawQueue.clear();
        m_drawCalls = 0;
    }
    
    void EndFrame() {
        FlushDrawQueue();
    }
    
    int GetDrawCallCount() const { return m_drawCalls; }
    
private:
    RenderSystem() = default;
    ~RenderSystem() = default;
    
    std::vector<DrawCommand> m_drawQueue;
    int m_drawCalls = 0;
    
    // Singleton - no copying
    RenderSystem(const RenderSystem&) = delete;
    RenderSystem& operator=(const RenderSystem&) = delete;
};

// Helper macro for submitting draw commands
#define SUBMIT_DRAW(sortKey, func, context) \
    RenderSystem::GetInstance().SubmitDrawCommand(sortKey, func, context)

#endif // RENDER_SYSTEM_HPP