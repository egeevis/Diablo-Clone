// camera_system.hpp - Kamera kontrol sistemi
#ifndef CAMERA_SYSTEM_HPP
#define CAMERA_SYSTEM_HPP

#include "raylib.h"
#include "core/constants.hpp"
#include "core/coordinate_system.hpp"
#include <cmath>

class CameraSystem {
public:
    // Kamera başlatma
    static void Initialize(Camera2D& camera, Vector2 target, 
                          int screenWidth, int screenHeight) {
        camera.target = target;
        camera.offset = {
            static_cast<float>(screenWidth) * 0.5f,
            static_cast<float>(screenHeight) * 0.5f
        };
        camera.rotation = 0.0f;
        camera.zoom = CameraConst::ZOOM_DEFAULT;
    }
    
    // Kamera güncelleme (player tracking)
    static void Update(Camera2D& camera, Vector2 target, 
                      const Vector2& worldBounds, float deltaTime) {
        // Smooth follow
        float smoothness = CameraConst::SMOOTHNESS;
        camera.target.x += (target.x - camera.target.x) * smoothness;
        camera.target.y += (target.y - camera.target.y) * smoothness;
        
        // Clamp to world bounds
        ClampToBounds(camera, worldBounds);
        
        // Zoom input
        HandleZoomInput(camera);
    }
    
    // Sınırlara clamp et
    static void ClampToBounds(Camera2D& camera, const Vector2& worldBounds) {
        float halfScreenW = GetScreenWidth() / (2.0f * camera.zoom);
        float halfScreenH = GetScreenHeight() / (2.0f * camera.zoom);
        
        // Minimum sınırlar
        float minX = halfScreenW;
        float minY = halfScreenH;
        
        // Maksimum sınırlar (harita boyutuna göre)
        float maxX = worldBounds.x - halfScreenW;
        float maxY = worldBounds.y - halfScreenH;
        
        // Sadece harita ekrandan büyükse clamp yap
        if (maxX > minX) {
            camera.target.x = fmaxf(minX, fminf(camera.target.x, maxX));
        }
        if (maxY > minY) {
            camera.target.y = fmaxf(minY, fminf(camera.target.y, maxY));
        }
    }
    
    // Zoom kontrolü
    static void HandleZoomInput(Camera2D& camera) {
        float wheelMove = GetMouseWheelMove();
        if (wheelMove != 0) {
            camera.zoom += wheelMove * 0.1f;
            camera.zoom = fmaxf(CameraConst::ZOOM_MIN, 
                              fminf(camera.zoom, CameraConst::ZOOM_MAX));
        }
        
        // Klavye zoom (PageUp/PageDown)
        if (IsKeyDown(KEY_PAGE_UP)) {
            camera.zoom += 0.02f;
        }
        if (IsKeyDown(KEY_PAGE_DOWN)) {
            camera.zoom -= 0.02f;
        }
        
        // Zoom clamp
        camera.zoom = fmaxf(CameraConst::ZOOM_MIN, 
                          fminf(camera.zoom, CameraConst::ZOOM_MAX));
    }
    
    // Kamera sallanma efekti (screen shake)
    static void ApplyScreenShake(Camera2D& camera, float intensity, 
                                float& shakeTimer, float deltaTime) {
        if (shakeTimer > 0) {
            shakeTimer -= deltaTime;
            
            // Rastgele offset
            float offsetX = (GetRandomValue(-100, 100) / 100.0f) * intensity;
            float offsetY = (GetRandomValue(-100, 100) / 100.0f) * intensity;
            
            camera.target.x += offsetX;
            camera.target.y += offsetY;
            
            // Intensity azalt
            intensity *= 0.9f;
        }
    }
    
    // Kamera rotasyonu (izometrik için 45 derece sabit)
    static void SetIsometricRotation(Camera2D& camera) {
        camera.rotation = 0.0f; // İzometrik projection math ile yapılıyor
    }
    
    // Ekran koordinatı → Dünya koordinatı
    static Vector2 ScreenToWorldPoint(const Camera2D& camera, Vector2 screenPoint) {
        return CoordinateSystem::ScreenToWorld(screenPoint, camera);
    }
    
    // Dünya koordinatı → Ekran koordinatı
    static Vector2 WorldToScreenPoint(const Camera2D& camera, Vector2 worldPoint) {
        return CoordinateSystem::WorldToScreen(worldPoint, camera);
    }
    
    // Kamera görünür alanını hesapla
    static Rectangle GetCameraViewport(const Camera2D& camera) {
        float width = GetScreenWidth() / camera.zoom;
        float height = GetScreenHeight() / camera.zoom;
        
        return {
            camera.target.x - width * 0.5f,
            camera.target.y - height * 0.5f,
            width,
            height
        };
    }
    
    // Nokta kameranın görüş alanında mı?
    static bool IsPointInView(const Camera2D& camera, Vector2 worldPoint, 
                             float margin = 0.0f) {
        Rectangle viewport = GetCameraViewport(camera);
        
        return (worldPoint.x >= viewport.x - margin &&
                worldPoint.x <= viewport.x + viewport.width + margin &&
                worldPoint.y >= viewport.y - margin &&
                worldPoint.y <= viewport.y + viewport.height + margin);
    }
};

#endif // CAMERA_SYSTEM_HPP