// movement_system.hpp - FPS-bağımsız hareket sistemi
#ifndef MOVEMENT_SYSTEM_HPP
#define MOVEMENT_SYSTEM_HPP

#include "constants.hpp"
#include "coordinate_system.hpp"
#include <cmath>

class MovementSystem {
public:
    // Constant speed movement (FPS-independent)
    static Vector2 MoveTowards(Vector2 current, Vector2 target, 
                               float speed, float deltaTime) {
        Vector2 direction = Vector2Subtract(target, current);
        float distance = Vector2Length(direction);
        
        if (distance <= Movement::ARRIVAL_THRESHOLD) {
            return target;
        }
        
        // Normalize and apply constant speed
        if (distance > 0.0001f) {
            direction.x /= distance;
            direction.y /= distance;
        }
        
        float moveDistance = speed * deltaTime;
        
        // Don't overshoot
        if (moveDistance > distance) {
            return target;
        }
        
        return {
            current.x + direction.x * moveDistance,
            current.y + direction.y * moveDistance
        };
    }
    
    // Smooth movement with lerp (camera/UI için)
    static Vector2 SmoothMoveTowards(Vector2 current, Vector2 target,
                                     float smoothTime, float deltaTime) {
        if (Vector2Distance(current, target) < 0.001f) {
            return target;
        }
        
        // Exponential smoothing
        float t = 1.0f - powf(0.01f, deltaTime / smoothTime);
        return Vector2Lerp(current, target, t);
    }
    
    // Grid-based movement validation
    static bool IsValidMovement(Vector2 fromGrid, Vector2 toGrid, 
                                const Map& map) {
        // Bounds check
        if (toGrid.x < 0 || toGrid.y < 0 || 
            toGrid.x >= map.GetWidth() || toGrid.y >= map.GetHeight()) {
            return false;
        }
        
        // Walkability check
        if (!map.IsWalkable(static_cast<int>(toGrid.x), 
                           static_cast<int>(toGrid.y))) {
            return false;
        }
        
        // Distance check (no teleport)
        float distance = CoordinateSystem::GridDistance(fromGrid, toGrid);
        if (distance > 1.5f) { // Max 1.5 tiles at once
            return false;
        }
        
        return true;
    }
    
    // Calculate movement direction vector
    static Vector2 CalculateDirection(Vector2 from, Vector2 to) {
        Vector2 dir = Vector2Subtract(to, from);
        float length = Vector2Length(dir);
        
        if (length > 0.0001f) {
            dir.x /= length;
            dir.y /= length;
        }
        
        return dir;
    }
    
    // Apply movement with physics constraints
    static void ApplyMovement(Player& player, float deltaTime) {
        if (!player.IsMoving()) return;
        
        // Constant speed movement
        Vector2 newPos = MoveTowards(
            player.GetWorldPosition(),
            player.GetTargetWorldPosition(),
            player.GetMoveSpeed(),
            deltaTime
        );
        
        player.SetWorldPosition(newPos);
        
        // Check if arrived
        if (Vector2Distance(newPos, player.GetTargetWorldPosition()) <= 
            Movement::ARRIVAL_THRESHOLD) {
            player.StopMoving();
        }
    }
};

#endif // MOVEMENT_SYSTEM_HPP