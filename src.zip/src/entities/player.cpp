// player.cpp - Player implementasyonu
#include "player.hpp"
#include "constants.hpp"
#include "coordinate_system.hpp"
#include "theme.hpp"
#include <cmath>

Player::Player() {
    m_worldPos = {400.0f, 300.0f};
    m_targetWorldPos = m_worldPos;
    m_gridPos = CoordinateSystem::WorldToGrid(m_worldPos);
    m_targetGridPos = m_gridPos;
    
    m_velocity = {0, 0};
    m_moveSpeed = Movement::BASE_SPEED;
    m_rotation = 0.0f;
    
    m_currentState = State::IDLE;
    m_stateString = "IDLE";
    
    m_color = Theme::PLAYER_PRIMARY;
    m_collisionRect = {
        m_worldPos.x - Player::COLLISION_WIDTH / 2.0f,
        m_worldPos.y - Player::COLLISION_HEIGHT / 2.0f,
        Player::COLLISION_WIDTH,
        Player::COLLISION_HEIGHT
    };
    
    m_showDebug = true;
    m_attackTimer = 0.0f;
    m_lastClickTime = 0.0f;
    m_isSprinting = false;
}

void Player::Initialize() {
    // Additional initialization if needed
}

void Player::MoveToGrid(Vector2 targetGrid, Camera2D camera) {
    m_targetGridPos = targetGrid;
    m_targetWorldPos = CoordinateSystem::GridToWorld(targetGrid);
    
    // Add camera offset for world position
    m_targetWorldPos.x += camera.target.x;
    m_targetWorldPos.y += camera.target.y;
    
    Vector2 direction = {
        m_targetWorldPos.x - m_worldPos.x,
        m_targetWorldPos.y - m_worldPos.y
    };
    
    float distance = Vector2Length(direction);
    if (distance <= Movement::ARRIVAL_THRESHOLD) {
        m_currentState = State::IDLE;
        return;
    }
    
    // Normalize direction
    if (distance > 0.0001f) {
        direction.x /= distance;
        direction.y /= distance;
    }
    
    // Calculate iso velocity
    float angle = 45.0f * DEG2RAD;
    m_velocity = {
        direction.x * cosf(angle) - direction.y * sinf(angle),
        direction.x * sinf(angle) + direction.y * cosf(angle)
    };
    
    // Normalize iso velocity
    float velLength = Vector2Length(m_velocity);
    if (velLength > 0.0001f) {
        m_velocity.x /= velLength;
        m_velocity.y /= velLength;
    }
    
    m_currentState = State::MOVING;
    UpdateStateString();
}

void Player::SetWorldPosition(Vector2 position) {
    m_worldPos = position;
    m_gridPos = CoordinateSystem::WorldToGrid(position);
    
    // Update collision rect
    m_collisionRect.x = position.x - m_collisionRect.width / 2.0f;
    m_collisionRect.y = position.y - m_collisionRect.height / 2.0f;
}

void Player::StopMoving() {
    m_velocity = {0, 0};
    m_currentState = State::IDLE;
    m_targetWorldPos = m_worldPos;
    m_targetGridPos = m_gridPos;
    UpdateStateString();
}

void Player::SetSprinting(bool sprinting) {
    m_isSprinting = sprinting;
    m_moveSpeed = sprinting ? Movement::SPRINT_SPEED : Movement::BASE_SPEED;
}

void Player::Draw() {
    // Draw player body (circle)
    DrawCircleV(m_worldPos, Player::RADIUS, m_color);
    
    // Draw direction indicator
    Vector2 facePos = {
        m_worldPos.x + cosf(m_rotation * DEG2RAD) * Player::RADIUS * 0.7f,
        m_worldPos.y + sinf(m_rotation * DEG2RAD) * Player::RADIUS * 0.7f
    };
    DrawCircleV(facePos, Player::RADIUS * 0.3f, Theme::PLAYER_SECONDARY);
    
    // Draw collision rect (debug)
    if (m_showDebug) {
        DrawRectangleLinesEx(m_collisionRect, 1.0f, GREEN);
    }
    
    // Draw movement trail if sprinting
    if (m_isSprinting && IsMoving()) {
        for (int i = 0; i < 3; i++) {
            float alpha = 0.3f - (i * 0.1f);
            Color trailColor = m_color;
            trailColor.a = static_cast<unsigned char>(alpha * 255);
            
            Vector2 trailPos = {
                m_worldPos.x - m_velocity.x * m_moveSpeed * 0.02f * (i + 1),
                m_worldPos.y - m_velocity.y * m_moveSpeed * 0.02f * (i + 1)
            };
            DrawCircleV(trailPos, Player::RADIUS * (0.8f - i * 0.2f), trailColor);
        }
    }
}

void Player::UpdateStateString() {
    switch (m_currentState) {
        case State::IDLE: m_stateString = "IDLE"; break;
        case State::MOVING: m_stateString = "MOVING"; break;
        case State::ATTACKING: m_stateString = "ATTACKING"; break;
        case State::INTERACTING: m_stateString = "INTERACTING"; break;
        default: m_stateString = "UNKNOWN"; break;
    }
}