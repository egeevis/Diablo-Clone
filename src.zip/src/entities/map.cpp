// map.cpp - Harita implementasyonu
#include "map.hpp"
#include "coordinate_system.hpp"
#include "theme.hpp"
#include <algorithm>

void Map::Initialize(int width, int height) {
    m_width = width;
    m_height = height;
    
    // Resize tiles vector
    m_tiles.resize(m_height);
    for (int y = 0; y < m_height; y++) {
        m_tiles[y].resize(m_width);
        for (int x = 0; x < m_width; x++) {
            m_tiles[y][x] = Tile(GetCheckerboardColor(x, y));
        }
    }
    
    GenerateProcedural();
}

void Map::Draw(Camera2D camera) const {
    // Calculate visible area for optimization
    Vector2 cameraWorld = camera.target;
    float visibleWidth = GetScreenWidth() / camera.zoom;
    float visibleHeight = GetScreenHeight() / camera.zoom;
    
    int startX = std::max(0, static_cast<int>(
        (cameraWorld.x - visibleWidth/2) / Grid::TILE_WIDTH_F) - 1);
    int endX = std::min(m_width, static_cast<int>(
        (cameraWorld.x + visibleWidth/2) / Grid::TILE_WIDTH_F) + 1);
    
    int startY = std::max(0, static_cast<int>(
        (cameraWorld.y - visibleHeight/2) / Grid::TILE_HEIGHT_F) - 1);
    int endY = std::min(m_height, static_cast<int>(
        (cameraWorld.y + visibleHeight/2) / Grid::TILE_HEIGHT_F) + 1);
    
    // Draw visible tiles
    for (int y = startY; y < endY; y++) {
        for (int x = startX; x < endX; x++) {
            DrawTile(x, y, camera);
        }
    }
}

Map::Tile Map::GetTile(int x, int y) const {
    if (IsWithinBounds(x, y)) {
        return m_tiles[y][x];
    }
    return Tile(); // Default tile
}

void Map::SetTile(int x, int y, const Tile& tile) {
    if (IsWithinBounds(x, y)) {
        m_tiles[y][x] = tile;
    }
}

bool Map::IsWalkable(int x, int y) const {
    if (IsWithinBounds(x, y)) {
        return m_tiles[y][x].walkable;
    }
    return false;
}

bool Map::IsWithinBounds(int x, int y) const {
    return x >= 0 && x < m_width && y >= 0 && y < m_height;
}

void Map::GenerateProcedural() {
    // Add some unwalkable tiles (rocks, etc.)
    for (int i = 0; i < (m_width * m_height) / 8; i++) {
        int x = GetRandomValue(0, m_width - 1);
        int y = GetRandomValue(0, m_height - 1);
        
        // Keep center area clear for player start
        if (abs(x - m_width/2) > 3 || abs(y - m_height/2) > 3) {
            m_tiles[y][x].walkable = false;
            m_tiles[y][x].color = Theme::GRID_UNWALKABLE;
        }
    }
    
    // Add some decorative objects
    for (int i = 0; i < (m_width * m_height) / 15; i++) {
        int x = GetRandomValue(2, m_width - 3);
        int y = GetRandomValue(2, m_height - 3);
        
        if (m_tiles[y][x].walkable) {
            m_tiles[y][x].hasObject = true;
            Color objColors[] = {
                {100, 150, 100, 255}, // Green (plant)
                {150, 100, 100, 255}, // Red (flower)
                {100, 100, 150, 255}  // Blue (water)
            };
            m_tiles[y][x].color = objColors[GetRandomValue(0, 2)];
        }
    }
}

Color Map::GetCheckerboardColor(int x, int y) const {
    return ((x + y) % 2 == 0) ? Theme::GRID_DARK : Theme::GRID_LIGHT;
}

void Map::DrawTile(int x, int y, Camera2D camera) const {
    const Tile& tile = m_tiles[y][x];
    Vector2 gridPos = {static_cast<float>(x), static_cast<float>(y)};
    
    Vector2 corners[4];
    CoordinateSystem::GetTileCorners(gridPos, camera, corners);
    
    // Draw tile body (diamond shape)
    DrawTriangle(corners[0], corners[1], corners[2], tile.color);
    DrawTriangle(corners[0], corners[2], corners[3], tile.color);
    
    // Draw unwalkable indicator
    if (!tile.walkable) {
        DrawLineEx(corners[0], corners[2], 2.0f, RED);
        DrawLineEx(corners[1], corners[3], 2.0f, RED);
    }
    
    // Draw object
    if (tile.hasObject) {
        Vector2 center = {
            (corners[0].x + corners[2].x) / 2.0f,
            (corners[1].y + corners[3].y) / 2.0f
        };
        DrawCircleV(center, 4.0f, WHITE);
        
        // Pulsing glow effect
        float pulse = sinf(GetTime() * 3.0f) * 0.5f + 0.5f;
        Color glow = tile.color;
        glow.a = static_cast<unsigned char>(100 * pulse);
        DrawCircleV(center, 6.0f, glow);
    }
    
    // Subtle border
    DrawLineEx(corners[0], corners[1], 0.5f, (Color){100, 100, 100, 100});
    DrawLineEx(corners[1], corners[2], 0.5f, (Color){100, 100, 100, 100});
    DrawLineEx(corners[2], corners[3], 0.5f, (Color){100, 100, 100, 100});
    DrawLineEx(corners[3], corners[0], 0.5f, (Color){100, 100, 100, 100});
}