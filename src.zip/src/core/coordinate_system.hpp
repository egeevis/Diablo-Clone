// coordinate_system.hpp - Düzeltilmiş
#ifndef COORDINATE_SYSTEM_HPP
#define COORDINATE_SYSTEM_HPP

#include "constants.hpp"
#include "raylib.h"
#include <cmath>

// Vector helper fonksiyonları (Raylib bağımlılığını azalt)
namespace VectorHelpers {
    inline float VectorDistance(Vector2 a, Vector2 b) {
        float dx = b.x - a.x;
        float dy = b.y - a.y;
        return sqrtf(dx * dx + dy * dy);
    }
    
    inline float VectorLength(Vector2 v) {
        return sqrtf(v.x * v.x + v.y * v.y);
    }
    
    inline Vector2 VectorSubtract(Vector2 a, Vector2 b) {
        return {a.x - b.x, a.y - b.y};
    }
    
    inline Vector2 VectorAdd(Vector2 a, Vector2 b) {
        return {a.x + b.x, a.y + b.y};
    }
    
    inline Vector2 VectorScale(Vector2 v, float scale) {
        return {v.x * scale, v.y * scale};
    }
    
    inline Vector2 VectorRotate(Vector2 v, float angle) {
        float cosA = cosf(angle);
        float sinA = sinf(angle);
        return {
            v.x * cosA - v.y * sinA,
            v.x * sinA + v.y * cosA
        };
    }
}

class CoordinateSystem {
public:
    static Vector2 GridToWorld(Vector2 gridPos) {
        return {
            (gridPos.x - gridPos.y) * GridConst::TILE_WIDTH_F * 0.5f,
            (gridPos.x + gridPos.y) * GridConst::TILE_HEIGHT_F * 0.5f
        };
    }
    
    static Vector2 WorldToGrid(Vector2 worldPos) {
        return {
            (worldPos.x / GridConst::TILE_WIDTH_F) + (worldPos.y / GridConst::TILE_HEIGHT_F),
            (worldPos.y / GridConst::TILE_HEIGHT_F) - (worldPos.x / GridConst::TILE_WIDTH_F)
        };
    }
    
    static Vector2 WorldToScreen(Vector2 worldPos, const Camera2D& camera) {
        Vector2 result = worldPos;
        result = VectorHelpers::VectorSubtract(result, camera.target);
        result = VectorHelpers::VectorRotate(result, camera.rotation * DEG2RAD);
        result = VectorHelpers::VectorScale(result, camera.zoom);
        result = VectorHelpers::VectorAdd(result, camera.offset);
        return result;
    }
    
    static Vector2 ScreenToWorld(Vector2 screenPos, const Camera2D& camera) {
        Vector2 result = screenPos;
        result = VectorHelpers::VectorSubtract(result, camera.offset);
        result = VectorHelpers::VectorScale(result, 1.0f / camera.zoom);
        result = VectorHelpers::VectorRotate(result, -camera.rotation * DEG2RAD);
        result = VectorHelpers::VectorAdd(result, camera.target);
        return result;
    }
    
    static Vector2 MouseToGrid(const Camera2D& camera) {
        Vector2 mouseScreen = GetMousePosition();
        Vector2 mouseWorld = ScreenToWorld(mouseScreen, camera);
        Vector2 gridPos = WorldToGrid(mouseWorld);
        
        gridPos.x = floorf(gridPos.x);
        gridPos.y = floorf(gridPos.y);
        
        return gridPos;
    }
    
    static float GridDistance(Vector2 a, Vector2 b) {
        float dx = a.x - b.x;
        float dy = a.y - b.y;
        return sqrtf(dx * dx + dy * dy);
    }
    
    static float WorldDistance(Vector2 a, Vector2 b) {
        return VectorHelpers::VectorDistance(a, b);
    }
    
    static void GetTileCorners(Vector2 gridPos, Camera2D camera, Vector2 corners[4]) {
        Vector2 worldPos = GridToWorld(gridPos);
        Vector2 screenPos = WorldToScreen(worldPos, camera);
        
        float halfW = GridConst::TILE_WIDTH_F * 0.5f * camera.zoom;
        float halfH = GridConst::TILE_HEIGHT_F * 0.5f * camera.zoom;
        
        corners[0] = {screenPos.x - halfW, screenPos.y};
        corners[1] = {screenPos.x, screenPos.y - halfH};
        corners[2] = {screenPos.x + halfW, screenPos.y};
        corners[3] = {screenPos.x, screenPos.y + halfH};
    }
};

#endif