// highlight.hpp - Grid highlight fonksiyonu
#ifndef HIGHLIGHT_HPP
#define HIGHLIGHT_HPP

#include "raylib.h"

void DrawPhantomHighlight(Vector2 gridPos, Camera2D camera);

#endif // HIGHLIGHT_HPP