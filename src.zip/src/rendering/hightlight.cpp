// highlight.cpp - Grid highlight implementasyonu
#include "rendering/highlight.hpp"
#include "coordinate_system.hpp"
#include "theme.hpp"
#include <cmath>

void DrawPhantomHighlight(Vector2 gridPos, Camera2D camera) {
    Vector2 corners[4];
    CoordinateSystem::GetTileCorners(gridPos, camera, corners);
    
    // Fill with low alpha
    Color fillColor = Theme::HIGHLIGHT;
    fillColor.a = static_cast<unsigned char>(Theme::HIGHLIGHT_ALPHA * 255);
    
    DrawTriangle(corners[0], corners[1], corners[2], fillColor);
    DrawTriangle(corners[0], corners[2], corners[3], fillColor);
    
    // Border with higher alpha
    Color borderColor = Theme::GOLD_TEXT;
    borderColor.a = 230; // ~90% alpha
    
    DrawLineEx(corners[0], corners[1], 2.0f, borderColor);
    DrawLineEx(corners[1], corners[2], 2.0f, borderColor);
    DrawLineEx(corners[2], corners[3], 2.0f, borderColor);
    DrawLineEx(corners[3], corners[0], 2.0f, borderColor);
    
    // Corner dots
    for (int i = 0; i < 4; i++) {
        DrawCircleV(corners[i], 2.0f, Theme::GOLD_TEXT);
    }
    
    // Pulsing glow effect
    static float pulseTime = 0.0f;
    pulseTime += GetFrameTime();
    
    float pulse = (sinf(pulseTime * 3.0f) * 0.3f + 0.7f);
    Color glowColor = Theme::HIGHLIGHT;
    glowColor.a = static_cast<unsigned char>(25 * pulse);
    
    // Slightly larger diamond for glow
    Vector2 glowCorners[4];
    for (int i = 0; i < 4; i++) {
        Vector2 center = {
            (corners[0].x + corners[2].x) / 2.0f,
            (corners[1].y + corners[3].y) / 2.0f
        };
        glowCorners[i] = {
            center.x + (corners[i].x - center.x) * 1.1f,
            center.y + (corners[i].y - center.y) * 1.1f
        };
    }
    
    DrawTriangle(glowCorners[0], glowCorners[1], glowCorners[2], glowColor);
    DrawTriangle(glowCorners[0], glowCorners[2], glowCorners[3], glowColor);
}