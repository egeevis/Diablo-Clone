// debug_overlay.hpp - Debug overlay (F1 ile aç/kapa)
#ifndef DEBUG_OVERLAY_HPP
#define DEBUG_OVERLAY_HPP

#include "constants.hpp"
#include "coordinate_system.hpp"
#include "theme.hpp"
#include <string>
#include <vector>

class DebugOverlay {
public:
    static DebugOverlay& GetInstance() {
        static DebugOverlay instance;
        return instance;
    }
    
    void Toggle() { m_enabled = !m_enabled; }
    bool IsEnabled() const { return m_enabled; }
    
    // Bilgi ekle
    void AddInfo(const std::string& label, const std::string& value) {
        m_debugInfo.push_back({label, value});
    }
    
    void AddInfo(const std::string& label, float value) {
        AddInfo(label, std::to_string(value));
    }
    
    void AddInfo(const std::string& label, Vector2 value) {
        std::string text = "[" + std::to_string(value.x) + 
                          ", " + std::to_string(value.y) + "]";
        AddInfo(label, text);
    }
    
    // Overlay'i çiz
    void Draw(const Camera2D& camera, Vector2 mouseGridPos, 
              const Player& player, float fps) {
        if (!m_enabled) return;
        
        DrawDebugPanel(camera, mouseGridPos, player, fps);
        DrawGridOverlay(camera);
        DrawMouseInfo(camera, mouseGridPos);
    }
    
    // Frame başında temizle
    void Clear() {
        m_debugInfo.clear();
    }
    
private:
    DebugOverlay() : m_enabled(true) {}
    
    void DrawDebugPanel(const Camera2D& camera, Vector2 mouseGridPos,
                       const Player& player, float fps) {
        int startX = UI::DEBUG_PADDING;
        int startY = UI::DEBUG_PADDING;
        int lineHeight = UI::DEBUG_LINE_HEIGHT;
        
        // Dynamic info
        Clear();
        AddInfo("FPS", fps);
        AddInfo("PLAYER POS", player.GetWorldPosition());
        AddInfo("PLAYER GRID", player.GetGridPosition());
        AddInfo("MOUSE GRID", mouseGridPos);
        AddInfo("STATE", player.GetStateString());
        AddInfo("SPEED", player.GetMoveSpeed());
        
        // Panel boyutunu hesapla
        int maxWidth = 0;
        for (const auto& [label, value] : m_debugInfo) {
            int width = MeasureText((label + ": " + value).c_str(), 
                                   UI::DEBUG_FONT_SIZE);
            maxWidth = std::max(maxWidth, width);
        }
        
        int panelWidth = maxWidth + 40;
        int panelHeight = (m_debugInfo.size() + 1) * lineHeight + 20;
        
        // Arkaplan
        Color bgColor = Theme::DEBUG_BACKGROUND;
        DrawRectangle(startX, startY, panelWidth, panelHeight, bgColor);
        
        // Bilgileri çiz
        int y = startY + 10;
        for (const auto& [label, value] : m_debugInfo) {
            // Label (Gold)
            DrawText((label + ":").c_str(), startX + 10, y, 
                    UI::DEBUG_FONT_SIZE, Theme::GOLD_TEXT);
            
            // Value (White)
            int textWidth = MeasureText(value.c_str(), UI::DEBUG_FONT_SIZE);
            DrawText(value.c_str(), startX + panelWidth - 10 - textWidth, y,
                    UI::DEBUG_FONT_SIZE, WHITE);
            
            y += lineHeight;
        }
    }
    
    void DrawGridOverlay(const Camera2D& camera) {
        // Grid hücrelerini göster
        Vector2 mouseGrid = CoordinateSystem::MouseToGrid(camera);
        Vector2 corners[4];
        CoordinateSystem::GetTileCorners(mouseGrid, camera, corners);
        
        // Highlight current grid cell
        Color highlight = {255, 255, 100, 50}; // %20 alpha
        DrawTriangle(corners[0], corners[1], corners[2], highlight);
        DrawTriangle(corners[0], corners[2], corners[3], highlight);
        
        // Grid lines
        DrawLineEx(corners[0], corners[1], 1.0f, Theme::GOLD_TEXT);
        DrawLineEx(corners[1], corners[2], 1.0f, Theme::GOLD_TEXT);
        DrawLineEx(corners[2], corners[3], 1.0f, Theme::GOLD_TEXT);
        DrawLineEx(corners[3], corners[0], 1.0f, Theme::GOLD_TEXT);
    }
    
    void DrawMouseInfo(const Camera2D& camera, Vector2 mouseGrid) {
        // Mouse koordinatlarını göster
        Vector2 mouseScreen = GetMousePosition();
        Vector2 mouseWorld = CoordinateSystem::ScreenToWorld(mouseScreen, camera);
        
        std::string screenText = "Screen: " + 
            std::to_string((int)mouseScreen.x) + ", " + 
            std::to_string((int)mouseScreen.y);
        
        std::string worldText = "World: " + 
            std::to_string((int)mouseWorld.x) + ", " + 
            std::to_string((int)mouseWorld.y);
        
        std::string gridText = "Grid: " + 
            std::to_string((int)mouseGrid.x) + ", " + 
            std::to_string((int)mouseGrid.y);
        
        int y = GetScreenHeight() - 100;
        DrawText(screenText.c_str(), 10, y, 16, GREEN);
        DrawText(worldText.c_str(), 10, y + 20, 16, YELLOW);
        DrawText(gridText.c_str(), 10, y + 40, 16, Theme::GOLD_TEXT);
    }
    
    bool m_enabled;
    std::vector<std::pair<std::string, std::string>> m_debugInfo;
};

#endif // DEBUG_OVERLAY_HPP